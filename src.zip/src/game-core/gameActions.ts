export const gameActions = {
  Textile_Mill: [
    "hire worker",
    "buy machine",
    "repair roof",
    "improve maintanance",
    "expand factory",
  ],
  Software_House: ["whatever"],
  Steel_Foundry: ["whatever2"],
};
